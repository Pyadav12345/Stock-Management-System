/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emart.pojo;

/**
 *
 * @author PRADEEP
 */
public class UserPojo {
     private  String password;
    private  String empid;
    private  String userid;
     private  String username;
    private  String usertype;

    public UserPojo() {
    }

    public UserPojo(String password, String empid, String userid, String username, String usertype) {
        this.password = password;
        this.empid = empid;
        this.userid = userid;
        this.username = username;
        this.usertype = usertype;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }
   
    
    
}
