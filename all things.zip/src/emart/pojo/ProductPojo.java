/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emart.pojo;

/**
 *
 * @author PRADEEP
 */
public class ProductPojo 
{

    public ProductPojo() {
    }
    private String p_Id;
    private String p_Name;
    private String p_CompanyName;
    private double p_OurPrice;
    private double p_Tax;
    private double quatity;

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    private double p_Price;
    private double total;

    public ProductPojo(String p_Id, String p_Name, String p_CompanyName, double p_OurPrice, double p_Tax, double quatity, double p_Price,double total) {
        this.p_Id = p_Id;
        this.p_Name = p_Name;
        this.p_CompanyName = p_CompanyName;
        this.p_OurPrice = p_OurPrice;
        this.p_Tax = p_Tax;
        this.quatity = quatity;
        this.p_Price = p_Price;
        this.total=total;
        
    }

    public String getP_Id() {
        return p_Id;
    }

    public void setP_Id(String p_Id) {
        this.p_Id = p_Id;
    }

    public String getP_Name() {
        return p_Name;
    }

    public void setP_Name(String p_Name) {
        this.p_Name = p_Name;
    }

    public String getP_CompanyName() {
        return p_CompanyName;
    }

    public void setP_CompanyName(String p_CompanyName) {
        this.p_CompanyName = p_CompanyName;
    }

    public double getP_OurPrice() {
        return p_OurPrice;
    }

    public void setP_OurPrice(double p_OurPrice) {
        this.p_OurPrice = p_OurPrice;
    }

    public double getP_Tax() {
        return p_Tax;
    }

    public void setP_Tax(double p_Tax) {
        this.p_Tax = p_Tax;
    }

    public double getQuatity() {
        return quatity;
    }

    public void setQuatity(double quatity) {
        this.quatity = quatity;
    }

    public double getP_Price() {
        return p_Price;
    }

    public void setP_Price(double p_Price) {
        this.p_Price = p_Price;
    }
    
}
