/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emart.Dao;

import emart.dbutil.DbConnection;
import emart.pojo.ProductPojo;
import emart.pojo.UserProfile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author PRADEEP
 */
public class OrderDao 
{
     public static String getNextOrderId() throws SQLException
    {
        Connection conn=DbConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("select max(p_id) from orders");
        rs.next();
        String O_Id=rs.getString(1);
                if(O_Id==null)
                    return "O-101";
        int O_no=Integer.parseInt(O_Id.substring(1));
        O_no=O_no+1;
        return "O"+O_no;
    
    }
     public static boolean addOrders(ArrayList<ProductPojo> al,String ordId)throws SQLException
    {
         Connection conn=DbConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("insert into orders values(?,?,?,?,?)");
int count=0;
for(ProductPojo p:al )
{
    ps.setString(1, ordId);
    ps.setString(2, p.getP_Id());
    ps.setDouble(3, p.getQuatity());
    ps.setString(4, UserProfile.getUserid());
    count=count+ps.executeUpdate();
}
         return count==al.size();
         
    }
    
}
