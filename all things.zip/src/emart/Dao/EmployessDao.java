/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emart.Dao;

import emart.dbutil.DbConnection;
import emart.pojo.EmployeesPojo;
//import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PRADEEP
 */
public class EmployessDao {
    public static String getNextEmpId() throws SQLException
    {
        Connection conn=DbConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("select max(empid) from EMPLOYEES");
        rs.next();
        String empId=rs.getString(1);
        int empno=Integer.parseInt(empId.substring(1));
        empno=empno+1;
        return "E"+empno;
        
    }
    public static boolean addEmployee(EmployeesPojo emp) throws SQLException
    {
        Connection conn=DbConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("insert into EMPLOYEES values(?,?,?,?)");
        ps.setString(1, emp.getEmpid());
        ps.setString(2,emp.getEmpname());
        ps.setString(3, emp.getJob());
        ps.setDouble(4, emp.getSalary());
        int result=ps.executeUpdate();
        return result==1;
    }
    public static List<EmployeesPojo> getAllEmployees() throws SQLException
    {
        Connection conn=DbConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("Select * from employees order by empid");
        ArrayList <EmployeesPojo> empList=new ArrayList<>();
        while(rs.next())
        {
            EmployeesPojo emp=new EmployeesPojo();
            emp.setEmpid(rs.getString(1));
            emp.setEmpname(rs.getString(2));
            emp.setJob(rs.getString(3));
            emp.setSalary(rs.getDouble(4));
            empList.add(emp);
        }
        return empList;
        
    }
    public static EmployeesPojo findById(String empId)throws SQLException
    {
        Connection conn= DbConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select * from employees where empid=?");
        ps.setString(1, empId);
        EmployeesPojo e=new EmployeesPojo();
        ResultSet rs=ps.executeQuery();
        rs.next();
        e.setEmpid(rs.getString(1));
        e.setEmpname(rs.getString(2));
        e.setJob(rs.getString(3));
        e.setSalary(rs.getDouble(4));
        return e;
    }
    public static boolean updateEmployee(EmployeesPojo e) throws SQLException
    {
        Connection conn=DbConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("update employees set empname=?,job=?,salary=? where empid=?");
        
        ps.setString(1, e.getEmpname());
        ps.setString(2, e.getJob());
        ps.setDouble(3, e.getSalary());
        ps.setString(4,e.getEmpid());
       
        int x=ps.executeUpdate();
        if(x==0)
            return false;
        else
        {
        
            boolean result=UserDao.isPresent(e.getEmpid());
            if(result==false)
                return true;
           
           ps=conn.prepareStatement("update users set usename=?,usertype=? where empid=?");
                      ps.setString(1,e.getEmpname());
           ps.setString(2, e.getJob());
        ps.setString(3, e.getEmpid());
 
          int y=ps.executeUpdate();
          return y==1;
            
        }
        
        }
    public static boolean deleteEmployee(String empid)throws SQLException
    {
          Connection conn=DbConnection.getConnection();
            PreparedStatement ps=conn.prepareStatement("delete from employees where empid=?");
            ps.setString(1, empid);
            int x=ps.executeUpdate();
            return x==1;
          
    }
     public static List getAllEmpid() throws SQLException
    {
        Connection conn=DbConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("Select * from employees order by empid");
        ArrayList<String> allId=new ArrayList<String>();
        while(rs.next())
        {
            allId.add(rs.getString(1));
        }
        return allId;
    }
}
