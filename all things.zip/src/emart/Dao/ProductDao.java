/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emart.Dao;

import emart.dbutil.DbConnection;
import emart.pojo.ProductPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PRADEEP
 */
 public class ProductDao {
    public static String getNextProductId() throws SQLException
    {
        Connection conn=DbConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("select max(p_id) from products");
        rs.next();
        String p_Id=rs.getString(1);
                if(p_Id==null)
                    return "P101";
        int p_no=Integer.parseInt(p_Id.substring(1));
        p_no=p_no+1;
        return "P"+p_no;
    }
    public static boolean addProducts(ProductPojo p)throws SQLException
    {
         Connection conn=DbConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("insert into products values(?,?,?,?,?,?,?,'Y')");
         ps.setString(1,p.getP_Id());
         ps.setString(2, p.getP_Name());
         ps.setString(3, p.getP_CompanyName());
         ps.setDouble(4, p.getP_Price());
         ps.setDouble(5, p.getP_OurPrice());
         ps.setDouble(6,p.getP_Tax());
         ps.setDouble(7, p.getQuatity());
         return ps.executeUpdate()==1;
         
    }
    
        
    public static List<ProductPojo>getProductDetails() throws SQLException
    {
       Connection conn=DbConnection.getConnection();
       Statement st=conn.createStatement();
       ResultSet rs=st.executeQuery("select * from products where status='Y' order by p_id");
       ArrayList<ProductPojo> productList=new ArrayList<>();
       while(rs.next())
       {
           ProductPojo p=new ProductPojo();
           p.setP_Id(rs.getString(1));
           p.setP_Name(rs.getString(2));
           p.setP_CompanyName(rs.getString(3));
           p.setP_Price(rs.getInt(4));
           p.setP_OurPrice(rs.getInt(5));
           p.setP_Tax(rs.getInt(6));
           p.setQuatity(rs.getInt(7));
           productList.add(p);
           
       }
       return productList;
    }
    public static boolean deleteProduct(String productId)throws SQLException
    {
         Connection conn=DbConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("update products set status='N' where P_ID=?");
         ps.setString(1, productId);
       int x=ps.executeUpdate();
            return x==1;
    }
public static boolean updtaeProduct(ProductPojo p)throws SQLException
{
  Connection conn=DbConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("update products set p_name=?,P_COMPNAYNAME=?,p_price=?,our_price=?,p_tax=?,QUANTITY=? where P_ID=?");
         

         ps.setString(1, p.getP_Name());
         ps.setString(2, p.getP_CompanyName());
         ps.setDouble(3,p.getP_Price());
         ps.setDouble(4, p.getP_OurPrice());
         ps.setDouble(5,p.getP_Tax());
         ps.setDouble(6, p.getQuatity());
         ps.setString(7, p.getP_Id());
         return ps.executeUpdate()==1;
}
public static ProductPojo getProductDetails(String id)throws SQLException
{
    Connection conn=DbConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("select * from products where p_id=? and status='Y'");
         ps.setString(1, id);
         ResultSet rs=ps.executeQuery();
         ProductPojo p=new ProductPojo();
        if( rs.next())
        {
            p.setP_Id(rs.getString(1));
           p.setP_Name(rs.getString(2));
           p.setP_CompanyName(rs.getString(3));
           p.setP_Price(rs.getInt(4));
           p.setP_OurPrice(rs.getInt(5));
           p.setP_Tax(rs.getInt(6));
           p.setQuatity(rs.getInt(7));
           
        }
        return p;
         
}
public static boolean updateStocks(ArrayList<ProductPojo> ProductList)throws SQLException
{
    Connection conn=DbConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("update products set quantity=? where P_ID=?");
         int x=0;
         for(ProductPojo p:ProductList)
         {
             ps.setString(2,p.getP_Id());
             ps.setDouble(1, p.getQuatity());
             int rows=ps.executeUpdate();
             if(rows!=0)
                 x++;
         }
         return x==ProductList.size();
}
}
