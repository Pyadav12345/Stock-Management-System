/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emart.Dao;

import emart.dbutil.DbConnection;
import emart.pojo.UserPojo;
import emart.pojo.UserProfile;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author PRADEEP
 */
public class UserDao {
    public static boolean validateUser(UserPojo uP)throws SQLException
    {
     Connection conn=   DbConnection.getConnection();
     PreparedStatement ps=conn.prepareStatement("Select * from users where userid=? and password=? and usertype=?");
    ps.setString(1, uP.getUserid());
    ps.setString(2, uP.getPassword());
    ps.setString(3, uP.getUsertype());
    ResultSet rs=ps.executeQuery();
    if(rs.next())
    {
        String username=rs.getString(5);
        UserProfile.setUsername(username);
    return true;
    
    }
    return false;
    
    }
public static boolean isPresent(String empid)   throws SQLException
{
      Connection conn=   DbConnection.getConnection();
       PreparedStatement ps=conn.prepareStatement("select * from users where empid=?");
       ps.setString(1, empid);
       ResultSet rs=ps.executeQuery();
       return rs.next();
    
}
}

